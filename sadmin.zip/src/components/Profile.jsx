import React, { useState } from 'react';
import axios from 'axios';

const baseServiceUrl = "https://students-manager.azurewebsites.net/api/students/";
const username = "guest";
const password = "guest";
const base64Auth = btoa(`${username}:${password}`);

const Profile = () => {
  const [facultyNumber, setFacultyNumber] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [base64Img, setBase64Img] = useState('');
  const [message, setMessage] = useState('');

  const sendPictureRequest = async () => {
    const requestData = {
      FacultyNumber: facultyNumber,
      Password: passwordInput,
      Picture: base64Img,
    };

    try {
      const response = await axios.put(`${baseServiceUrl}picture`, JSON.stringify(requestData), {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${base64Auth}`,
        },
      });
      // Handle successful request
      setMessage('Profile updated successfully.');
      console.log('Success:', response.data);
    } catch (error) {
      // Handle request error
      setMessage('Error updating profile.');
      console.error('Error:', error);
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Profile</h2>
      {message && <div className={`alert ${message === 'Profile updated successfully.' ? 'alert-success' : 'alert-danger'}`}>{message}</div>}
      <div className="mb-3">
        <label htmlFor="facultyNumber" className="form-label">Faculty Number:</label>
        <input 
          type="text" 
          className="form-control" 
          id="facultyNumber" 
          value={facultyNumber} 
          onChange={(e) => setFacultyNumber(e.target.value)} 
        />
      </div>
      <div className="mb-3">
        <label htmlFor="password" className="form-label">Password:</label>
        <input 
          type="password" 
          className="form-control" 
          id="password" 
          value={passwordInput} 
          onChange={(e) => setPasswordInput(e.target.value)} 
        />
      </div>
      <div className="mb-3">
        <label htmlFor="base64Image" className="form-label">Base64 Image:</label>
        <input 
          type="text" 
          className="form-control" 
          id="base64Image" 
          value={base64Img} 
          onChange={(e) => setBase64Img(e.target.value)} 
        />
      </div>
      <button className="btn btn-primary" onClick={sendPictureRequest}>Submit</button>
    </div>
  );
};

export default Profile;