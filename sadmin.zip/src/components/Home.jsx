import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const baseServiceUrl = "https://students-manager.azurewebsites.net/api/students/";
const username = "guest";
const password = "guest";
const base64Auth = btoa(`${username}:${password}`);

const Home = () => {
  const [students, setStudents] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await axios.get(baseServiceUrl, {
          headers: {
            "Authorization": `Basic ${base64Auth}`,
          },
        });
        setStudents(response.data);
      } catch (error) {
        setError("Error fetching students");
        console.error(error);
      }
    };

    fetchStudents();
  }, []);

  return (
    <div className="container mt-4">
      <h1 className="text-center">Welcome</h1>
      <br />
      {error && <div className="alert alert-danger">{error}</div>}
      <ul className="list-group" id="results">
        {students.map((student) => (
          <li key={student.id} className="list-group-item d-flex justify-content-between align-items-center">
            <Link 
              to="/details"
              state={{ student }}
              className="text-decoration-none"
            >
              {student.fullName}
            </Link>
            <i className="bi bi-arrow-right"></i>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Home;